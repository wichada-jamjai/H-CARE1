package com.example.a401app_v1;

import android.app.Activity;
import android.os.Bundle;
import android.telecom.Call;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;

public class Notification_Activity extends Activity {

    private LinearLayout noNoti, caloriesNoti, cholesterolNoti, sodiumNoti, sugarNoti;
    private Button close;
    Bundle extras;
    String toNoti;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification_popup);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        getWindow().setLayout((int)width, WindowManager.LayoutParams.MATCH_PARENT);

        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.gravity = Gravity.CENTER;
        params.x = 0;
        params.y = -20;

        getWindow().setAttributes(params);

        noNoti = findViewById(R.id.noNoti);
        caloriesNoti = findViewById(R.id.caloriesNoti);
        cholesterolNoti = findViewById(R.id.cholesterolNoti);
        sodiumNoti= findViewById(R.id.sodiumNoti);
        sugarNoti= findViewById(R.id.sugarNoti);

        close = findViewById(R.id.closeNoti);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                overridePendingTransition(R.anim.fadeout, R.anim.fadeout);
            }
        });

        extras = getIntent().getExtras();
        toNoti = extras.getString("noti");

        if(toNoti.equals("cal")){
            noNoti.setVisibility(View.GONE);
            caloriesNoti.setVisibility(View.VISIBLE);
        }


    }
}
